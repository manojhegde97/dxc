package com.myhibspr.demo;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mysprhib.dao.MobileDao;
import com.mysprhib.model.Mobile;

@Controller
public class HomeController {
	
	@Autowired
	MobileDao mobiledao;
	@RequestMapping(value = "/")
	public String home(Model model) {	
		return "home";
	}
	@RequestMapping(value="/savemobile")
  public String home(@ModelAttribute Mobile mobile) {
		mobiledao.SaveMobile(mobile);
		return "home";
	}
	@RequestMapping(value="/getmobiles")
	public String home1(Model model) {
		ArrayList<Mobile> mobile=mobiledao.GetMobiles();
		model.addAttribute("mobiles",mobile);
		return "display";
	}
	@RequestMapping(value="/del")
	public String home2(Model model)
	{
		return "del";
	}
	@RequestMapping(value="/getmobilesbyid")
	public String home5(Model model)
	{
		return "getbyid";
	}
	@RequestMapping(value="/deletemobile")
	public String home7(Model model,@RequestParam("id") int id) {
		mobiledao.DeleteMobileById(id);
		return "home";
	}
	@RequestMapping(value="/getmobile")
	public String home1(Model model,@RequestParam("id") int id) {
		Mobile mobile=mobiledao.GetMobileById(id);
		model.addAttribute("mobile",mobile);
		return "display2";
	}
	@RequestMapping(value="/back")
	public String home3(Model model) {	
		return "home";
	}
	@RequestMapping(value = "/update")
	public String update(Model model) {	
		return "update";
	}
	@RequestMapping(value="/updatecost")
	public String home1(@RequestParam("id") int id,@RequestParam("cost") int cost ) {
		mobiledao.updateCost(id,cost);
		return "home";
	}
}
