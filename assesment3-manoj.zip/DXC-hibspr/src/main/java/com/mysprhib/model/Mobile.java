package com.mysprhib.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.xml.ws.soap.Addressing;

@Entity
public class Mobile {
@Id
@GeneratedValue(strategy=GenerationType.SEQUENCE)
int id;
String brand;
String modelname;
int cost;

public int getCost() {
	return cost;
}
public void setCost(int cost) {
	this.cost = cost;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getBrand() {
	return brand;
}
public void setBrand(String brand) {
	this.brand = brand;
}
public String getModelname() {
	return modelname;
}
public void setModelname(String modelname) {
	this.modelname = modelname;
}

}
