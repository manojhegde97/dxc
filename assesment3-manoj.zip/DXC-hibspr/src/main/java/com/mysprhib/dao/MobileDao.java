package com.mysprhib.dao;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mysprhib.model.Mobile;



@Component
public class MobileDao {
@Autowired
SessionFactory sessionfactory;
@Transactional
 	public void SaveMobile(Mobile mobile) 
	{
	Session session=sessionfactory.getCurrentSession();
	session.save(mobile);
	}
@Transactional
	public ArrayList<Mobile> GetMobiles()
	{
		Session session=sessionfactory.getCurrentSession();
		ArrayList<Mobile> mobiles=(ArrayList<Mobile>) session.createQuery("from Mobile").list();
		return mobiles;
	}
@Transactional
public Mobile GetMobileById(int id)
{
	Session session=sessionfactory.getCurrentSession();
	Mobile mobile=(Mobile) session.get(Mobile.class,id);
	return mobile;
}
@Transactional
	public void DeleteMobileById(int id)
	{
		Session session=sessionfactory.getCurrentSession();
		//Mobile mobile=(Mobile) session.get(Mobile.class, id);
		session.delete(GetMobileById(id));
	}

@Transactional
public void updateCost(int id,int cost)
{
Session session=sessionfactory.getCurrentSession();
Mobile mobile=(Mobile) session.get(Mobile.class, id);
mobile.setCost(cost);
}
}
