export interface  Resturant{
  resturantId:number;
  resturantName:String;
  location:String;
  rating:number;
}
