import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ser',
  templateUrl: './ser.component.html',
  styleUrls: ['./ser.component.css']
})
export class SerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
